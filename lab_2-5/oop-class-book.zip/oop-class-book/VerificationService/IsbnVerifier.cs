﻿using System;

namespace VerificationService
{

    /// Проверяет, является ли строковое представление номера действительным идентификационным номером ISBN-10 или ISBN-13 книги.

    public static class IsbnVerifier
    {

        /// Проверяет, является ли строковое представление номера действительным идентификационным номером ISBN-10 или ISBN-13 книги.
        /// <param name="isbn">The string representation of book's isbn.</param> строкое представление ISBN книги
        /// <returns>верно, если номер является действительным идентификационным номером ISBN-10 или ISBN-13 книги, неверно в противном случае.</returns>
        /// <exception cref="ArgumentNullException">Thrown if isbn is null.</exception> Выбрасывается, если = 0
        public static bool IsValid(string isbn)
        {
            if (isbn is null)
            {
                throw new ArgumentNullException();
            }

            return isbn.Length switch
            {
                    13 => IsValidISBN10(isbn),
                    17 => IsValidISBN13(isbn),
                    _ => false
            };
        }

        private static bool IsValidISBN10(string isbn)
        {
            if (string.IsNullOrEmpty(isbn))
            {
                return false;
            }

            long j;
            if (isbn.Contains('-'))
            {
                isbn = isbn.Replace("-", "");
            }

            if (!Int64.TryParse(isbn[..^1], out j))
            {
                return false;
            }

            char lastChar = isbn[^1];
            if (lastChar == 'X' && !Int64.TryParse(lastChar.ToString(), out j))
            {
                return false;
            }
           
            int sum = 0;
            for (int i = 0; i < 9; i++)
                sum += Int32.Parse(isbn[i].ToString()) * (i + 1);

            return sum % 11 == int.Parse(isbn[9].ToString());
        }

        private static bool IsValidISBN13(string isbn)
        {
            if (string.IsNullOrEmpty(isbn))
            {
                return false;
            }

            long j;
            if (isbn.Contains('-'))
            {
                isbn = isbn.Replace("-", "");
            }
            if (!Int64.TryParse(isbn, out j))
            {
                return false;
            }
            
            int sum = 0;
            for (int i = 0; i < 12; i++)
            {
                sum += Int32.Parse(isbn[i].ToString()) * (i % 2 == 1 ? 3 : 1);
            }

            int remainder = sum % 10; // контрольная сумма
            int checkDigit = 10 - remainder;
            if (checkDigit == 10)
            {
                checkDigit = 0;
            } 

            return checkDigit == int.Parse(isbn[12].ToString());
        }
    }
}
