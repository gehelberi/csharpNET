﻿using System;
using System.Globalization;
using System.Linq;

namespace VerificationService
{
    /// Класс для проверки строк валюты.
    public static class IsoCurrencyValidator
    {
        /// Определяет, является ли указанная строка допустимым символом валюты ISO.
        /// <param name="currency">Строка валюты для проверки.</param>
        /// <returns>
        /// <see langword="true"/> если <paramref name="currency"/> является допустимым символом валюты ISO; 
        /// <see langword="false"/> в противном случае.
        /// </returns>
        /// <exception cref="ArgumentException">Выбрасывается, если значение валюты равно нулю или пусто, или пробел.</exception>
        public static bool IsValid(string currency)
        {
            CultureInfo[] cultures = CultureInfo.GetCultures(CultureTypes.SpecificCultures);
            if (cultures
                    .Select(ci => new RegionInfo(ci.LCID))
                    .Any(ri => ri.ISOCurrencySymbol == currency)
            )
            {
                return true;
            }

            throw new ArgumentException();
        }
    }
}
