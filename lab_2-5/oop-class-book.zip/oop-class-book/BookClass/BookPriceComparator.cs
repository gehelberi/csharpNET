﻿using System.Collections.Generic;

namespace BookClass
{
    /// <summary>Book Price Comparator.</summary>
    public class BookPriceComparator : IComparer<Book>
    {
        /// <summary>Сравнивает две книги по цене.</summary>
        /// <param name="firstBook">First book to compare.</param>
        /// <param name="secondBook">Second book to compare.</param>
        /// <returns>int.</returns>
        public int Compare(Book firstBook, Book secondBook)
        {
            return firstBook switch
            {
                    null when secondBook == null => 0,
                    null => -1,
                    _ => secondBook == null ? 1 : firstBook.Price.CompareTo(secondBook.Price)
            };
        }
    }
}
