﻿using System;
using System.Globalization;
using VerificationService;

namespace BookClass // запечатанный класс с именем Book
{
    /// Представляет книгу как тип издания.

    public sealed class Book : IEquatable<Book>, IComparable<Book>, IComparable        // реализация интефейсов
    {

        /// Получает автора книги.

        public readonly string Author;  // св-во только для чтения


        /// Получает название книги.

        public readonly string Title;   // св-во только для чтения


        /// Получает издателя книги.

        public readonly string Publisher;   // св-во, доступное только для чтения


        /// Получает ISBN.

        public readonly string ISBN;                             // св-во только для чтения

        private bool published;                                  // приватное поле, связанное с публикацией (оно истинно), если 

        private DateTime datePublished;                          // назначается дате публикации, иначе - false 

        private int totalPages;                                  // указывает, сколько всего страниц в книге; св-во чтения/записи


        /// Получает или задает общее кол-во страниц в книге.

        /// <exception cref="ArgumentOutOfRangeException">Throw when Pages less or equal zero.</exception> выбрасывать, когда страниц <= 0
        public int Pages
        {
            get
            {
                return this.totalPages;
            }

            set
            {
                if (value <= 0)
                {
                    throw new ArgumentOutOfRangeException(nameof(value));   // выбрасывается, если totalPages < 0
                }

                this.totalPages = value;
            }
        }


        /// Получает цену.

        public decimal Price { get; private set; }       // св-во, связанное с ценой


        /// Получает валюту.

        public string Currency { get; private set; }    // св-во, связанное с ценой

        /// Инициализирует новый экземпляр <see cref="Book"/> класса.
        /// <param name="author">Author of the book.</param>
        /// <param name="title">Title of the book.</param>
        /// <param name="publisher">Publisher of the book.</param>
        /// <exception cref="ArgumentNullException">Throw when author or title or publisher is null.</exception>
        public Book(string author, string title, string publisher)      // конструктор Book с тремя параметрами
        {
            this.Author = author ?? throw new ArgumentNullException(nameof(author));
            this.Title = title ?? throw new ArgumentNullException(nameof(title));
            this.Publisher = publisher ?? throw new ArgumentNullException(nameof(publisher));
        }

        /// Инициализирует новый экземпляр <see cref="Book"/> класса.
        /// <param name="author">Author of the book.</param>
        /// <param name="title">Title of the book.</param>
        /// <param name="publisher">Publisher of the book.</param>
        /// <param name="isbn">International Standard Book Number.</param>
        /// <exception cref="ArgumentNullException">Throw when author or title or publisher or ISBN is null.</exception>
        public Book(string author, string title, string publisher, string isbn) // второй конструктор, включающий ISBN параметр
                : this(author, title, publisher)
        {
            if (isbn is null)
            {
                throw new ArgumentNullException(nameof(isbn));
            }

            if (isbn == string.Empty)
            {
                this.ISBN = isbn;
            }
            else if (IsbnVerifier.IsValid(isbn))
            {
                this.ISBN = isbn;
            }
        }


        /// Публикует книгу, если она еще не была опубликована.
        /// <param name="dateTime">Date of publish.</param>
        public void Publish(DateTime dateTime) =>
                (this.published, this.datePublished) = (true, dateTime);

        /// Получает информацию о времени публикации.
        /// <returns>Строка "ТИП", если книга не опубликована, и значение даты публикации, если она опубликована.</returns>
        public string GetPublicationDate() => this.published    // метод, возвращающий строку 
                ? this.datePublished.ToString("MM/dd/yyyy", CultureInfo.CreateSpecificCulture("en-US")) 
                : "NYP";

        /// Устанавливает цену и валюту книги.
        /// <param name="price">Price of book.</param>
        /// <param name="currency">Currency of book.</param>
        /// <exception cref="ArgumentException">Throw when Price less than zero or currency is invalid.</exception>
        /// <exception cref="ArgumentNullException">Throw when currency is null.</exception>
        public void SetPrice(decimal price, string currency) // метод, устанавливающий значения цены и валюты
        {
            if (price < 0)
            {
                throw new ArgumentException(nameof(this.Price));
            }

            if (currency is null)
            {
                throw new ArgumentNullException(nameof(currency));
            }

            if (!IsoCurrencyValidator.IsValid(currency))        // символы валюты
            {
                throw new ArgumentException(nameof(this.Currency));
            }

            this.Currency = currency;
            this.Price = price;
        }

        /// Строкое представление книги.
        /// <returns>Представление книги.</returns>
        public override string ToString() => $"{this.Title} by {this.Author}";  // метод, возвращающий информацию об авторе и название

        /// Проверить 2 книги на рав-во.
        /// <param name="obj">Экземпляр класса Book для сравнения с.</param>
        /// <returns>Истинно, если книги равны, в противном случае ложно.</returns>
        public override bool Equals(object obj) // метод интерфейса
        {
            return obj is Book book && (base.Equals(book) && this.ISBN == book.ISBN);
        }

        /// Реализовать равное равенство по значению ISBN.
        /// <param name="other">Экземпляр класса Book для сравнения с.</param>
        /// <returns>Истинно, если книги равны, в противном случае ложно.</returns>
        public bool Equals(Book other)
        {
            if (other is null)
            {
                return false;
            }
            
            return this.Author.Equals(other.Author, StringComparison.Ordinal)
                   && this.Title.Equals(other.Title, StringComparison.Ordinal)
                   && this.Publisher.Equals(other.Publisher, StringComparison.Ordinal)
                   && this.ISBN == other.ISBN;
        }
        
        /// <summary>Сравнение названий книг.</summary>
        /// <param name="obj">Object</param>
        /// <exception cref="ArgumentNullException">Throw when book's isbn is null.</exception>
        /// <returns>Рав-во ISBN книг</returns>
        public int CompareTo(object obj)    // метод интерфейса
        {
            return this.CompareTo(obj as Book);
        }

        /// <summary>Сранвнение названий книг.</summary>
        /// <param name="other">Экземпляр класса Book.</param>
        /// <exception cref="ArgumentNullException">Throw when book's isbn is null.</exception>
        /// <returns>Рав-во ISBN книг</returns>
        public int CompareTo(Book other)
        {
            if (other is null)
            {
                return -1;
            }

            if (this.Title.Equals(other.Title, StringComparison.OrdinalIgnoreCase))       // сравнение по Title
            {
                return 0;
            }

            return this.Title.Length < other.Title.Length ? 1 : -1;
        }

        /// Переопределить System.Object метода получения хэш-кода.
        /// <returns>Хэш-код, представляющий три значения.</returns>
        public override int GetHashCode()       // метод, переопределяющий реализацию интерфейса
        {
            return HashCode.Combine(this.Author, this.Title, this.Publisher);
        }
    }
}
