
namespace _21_11_2021.Models
{
    public enum Status
    {
        Сompleted,
        Planned,
        Recruiting,
        InProgress
    }
}

