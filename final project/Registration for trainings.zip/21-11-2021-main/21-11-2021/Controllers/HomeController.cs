﻿using _21_11_2021.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace _21_11_2021.Controllers
{
    public class HomeController : Controller        // логика приложения с методами действия
    {

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ViewResult RegistrationForm()
        {
            ViewBag.Universities = new List<string> { "BSU", "BSUIR", "BNTU", "BSTU" };
            ViewBag.Courses = new List<string> { "iOS development", "Android development", "Java development"}; // зарегистрироваться можно
                                                                                                                // только на курс со статусом
                                                                                                                // Recruiting
            return View();
        }

        [HttpPost]
        public ViewResult RegistrationForm(Member member)
        {
            if (ModelState.IsValid)
            {
                Repository.AddMember(member);
                return View("Thanks", member);
            }
            else
            {
                return View();
            }
        }

        public ViewResult Members()
        {
            return View(Repository.Members);
        }

        public ViewResult Trainings()
        {
            return View(Repository.Trainings);
        }

        public IActionResult Privacy()
        {
            return View();
        }

      

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
