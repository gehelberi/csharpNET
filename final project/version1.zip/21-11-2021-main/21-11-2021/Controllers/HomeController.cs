﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using RegistrationForCourses.Entities;
using RegistrationForCourses.Models;
using RegistrationForCourses.Repositories;
using System.Diagnostics;

namespace RegistrationForCourses.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult AllCourses()
        {
            return View(DataRepository.GetCourses());
        }

        public IActionResult RegistrationForm(int courseId)
        {
            return View(new GuestResponse(courseId));
        }

        public IActionResult ListenersOnCourse(int courseId)
        {
            return View(DataRepository.GetListenersForCourse(courseId));
        }

        public IActionResult RegisterUser(GuestResponse response)
        {
            var listener = new Listener();
            listener.fkCourseId = response.CourseId;
            listener.name = response.Name;
            listener.email = response.Email;
            listener.phone = response.Phone;
            listener.university = response.University;
            listener.course = (AssignedCourseType)response.Course;
            DataRepository.AddListener(listener);
            return View("RegistrationForm");
        }



        
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
