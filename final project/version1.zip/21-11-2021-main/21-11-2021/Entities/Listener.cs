﻿namespace RegistrationForCourses.Entities
{
    public class Listener
    {
        public string name;
        public string phone;
        public string email;
        public string university;
        public AssignedCourseType course;
        public int fkCourseId;

    }
    public enum AssignedCourseType
    {
        AutomatedTesting,
        MobileDevelopment,
        JavaDevelopment,
        WebDevelopment,
        BusinessAnalytics,
        BigData
    }
}
