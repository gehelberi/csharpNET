﻿using System;
using System.Collections.Generic;

namespace RegistrationForCourses.Entities
{
    public class Course // название, дата старта, продолжительность, статус
    {
        private readonly int id;
        public string title;
        public DateTime startDate;
        public int duration;
        public Status status;
        public Course(int id)
        {
            this.id = id;
        }

        public int GetId()
        {
            return this.id;
        }

    }
    public enum Status
    {
        Completed,
        Planned,
        Recruting,
        Progress
    }
}
