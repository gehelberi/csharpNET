﻿using RegistrationForCourses.Entities;
using System.Collections.Generic;
using System.Linq;

namespace RegistrationForCourses.Repositories
{
    public static class DataRepository
    {
        private static List<Course> Courses { get; set; } = new List<Course>() {
            new Course(1)
            {
                title = "MobileDevelopment", 
                duration = 12, 
                startDate = new System.DateTime(2021,09,01),
                status = Status.Progress
            },
            new Course(2)
            {
                title = "MobileDevelopment",
                duration = 3,
                startDate = new System.DateTime(2021,09,01),
                status = Status.Completed
            },
            new Course(3)
            {
                title = "AutomatedTesting",
                duration = 5,
                startDate = new System.DateTime(2021,09,01),
                status = Status.Progress
            },
            new Course(4)
            {
                title = "AutomatedTesting",
                duration = 3,
                startDate = new System.DateTime(2022,02,01),
                status = Status.Planned
            },
            new Course(5)
            {
                title = "JavaDevelopment",
                duration = 3,
                startDate = new System.DateTime(2022,01,15),
                status = Status.Recruting
            },
            new Course(6)
            {
                title = "WebDevelopment",
                duration = 5,
                startDate = new System.DateTime(2022,01,21),
                status = Status.Planned
            },
            new Course(7)
            {
                title = "BusinessAnalytics",
                duration = 5,
                startDate = new System.DateTime(2022,01,21),
                status = Status.Recruting
            },
            new Course(8)
            {
                title = "BusinessAnalytics",
                duration = 5,
                startDate = new System.DateTime(2021,10,12),
                status = Status.Progress
            },
            new Course(9)
            {
                title = "BigData",
                duration = 5,
                startDate = new System.DateTime(2022,01,21),
                status = Status.Recruting
            },
            new Course(10)
            {
                title = "BigData",
                duration = 5,
                startDate = new System.DateTime(2022,03,21),
                status = Status.Planned
            },

        };
        private static List<Listener> Listeners { get; set; } = new List<Listener>() {
        };
        
        public static void AddListener (Listener listener)
        {
            Listeners.Add(listener);
        }

        public static List<Course> GetCourses()
        {
            return Courses;
        }

        public static List<Listener> GetListenersForCourse(int courseId)
        {
            var listeners = Listeners.Where(l => l.fkCourseId == courseId).ToList();
            return listeners;
        }
    }
}
